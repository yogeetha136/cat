const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// MongoDB connection
const uri = "mongodb+srv://yogeetha136:yogee123@concerto.jtmbj.mongodb.net/?retryWrites=true&w=majority&appName=concerto";
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
const dbName = "school";
const collectionName = "school11";

// Connect to MongoDB
async function connectDB() {
  try {
    await client.connect();
    console.log("Connected to MongoDB Atlas");
  } catch (err) {
    console.error("Error connecting to MongoDB:", err);
    process.exit(1); // Exit process if database connection fails
  }
}
connectDB();

// Add a new event
app.post('/events', async (req, res) => {
  const { name, phone, email, eventName, eventDate } = req.body;

  if (!name || !phone || !email || !eventName || !eventDate) {
    return res.status(400).send({ message: "All fields are required" });
  }

  try {
    const db = client.db(dbName);
    const result = await db.collection(collectionName).insertOne(req.body);
    console.log("Event added:", result); // Debugging log
    res.status(201).send({ message: "Event added successfully", id: result.insertedId });
  } catch (err) {
    console.error("Error adding event:", err);
    res.status(500).send({ message: "Error adding event" });
  }
});

// Get all events
app.get('/events', async (req, res) => {
  try {
    const db = client.db(dbName);
    const events = await db.collection(collectionName).find().toArray();
    res.status(200).send(events);
  } catch (err) {
    console.error("Error retrieving events:", err);
    res.status(500).send({ message: "Error retrieving events" });
  }
});

// Update an event
app.put('/events/:id', async (req, res) => {
  const { id } = req.params;

  if (!ObjectId.isValid(id)) {
    return res.status(400).send({ message: "Invalid ID" });
  }

  try {
    const db = client.db(dbName);
    const result = await db.collection(collectionName).updateOne(
      { _id: new ObjectId(id) },
      { $set: req.body }
    );

    if (result.matchedCount === 0) {
      return res.status(404).send({ message: "Event not found" });
    }

    res.status(200).send({ message: "Event updated successfully" });
  } catch (err) {
    console.error("Error updating event:", err);
    res.status(500).send({ message: "Error updating event" });
  }
});

// Delete an event
app.delete('/events/:id', async (req, res) => {
  const { id } = req.params;

  if (!ObjectId.isValid(id)) {
    return res.status(400).send({ message: "Invalid ID" });
  }

  try {
    const db = client.db(dbName);
    const result = await db.collection(collectionName).deleteOne({ _id: new ObjectId(id) });

    if (result.deletedCount === 0) {
      return res.status(404).send({ message: "Event not found" });
    }

    res.status(200).send({ message: "Event deleted successfully" });
  } catch (err) {
    console.error("Error deleting event:", err);
    res.status(500).send({ message: "Error deleting event" });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
