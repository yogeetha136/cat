const express = require('express');
const app = express();
const port = 3000;

app.use(express.json()); // To parse JSON request bodies

// In-memory array to store student data
let students = [];

// Create a new student (POST /api/students)
app.post('/api/students', (req, res) => {
    const { id, name, department, course } = req.body;
    
    // Check if student ID already exists
    if (students.some(student => student.id === id)) {
        return res.status(400).json({ message: 'Student with this ID already exists' });
    }
    
    const newStudent = { id, name, department, course };
    students.push(newStudent);
    res.status(201).json(newStudent); // Return the newly added student
});

// Read all students (GET /api/students)
app.get('/api/students', (req, res) => {
    res.json(students); // Return the list of students
});

// Update a student by ID (PUT /api/students/:id)
app.put('/api/students/:id', (req, res) => {
    const studentId = req.params.id;
    const { name, department, course } = req.body;

    const studentIndex = students.findIndex(student => student.id === studentId);
    if (studentIndex === -1) {
        return res.status(404).json({ message: 'Student not found' });
    }

    // Update student information
    if (name) students[studentIndex].name = name;
    if (department) students[studentIndex].department = department;
    if (course) students[studentIndex].course = course;

    res.json(students[studentIndex]); // Return the updated student
});

// Delete a student by ID (DELETE /api/students/:id)
app.delete('/api/students/:id', (req, res) => {
    const studentId = req.params.id;

    const studentIndex = students.findIndex(student => student.id === studentId);
    if (studentIndex === -1) {
        return res.status(404).json({ message: 'Student not found' });
    }

    students.splice(studentIndex, 1); // Remove student from array
    res.json({ message: 'Student deleted successfully' });
});

// Serve the frontend (index.html)
const path = require('path');
app.use(express.static(path.join(__dirname, 'public')));

// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
