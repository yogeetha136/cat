async function bookTrain() {
    const train = {
        name: document.getElementById('bookTrainName').value,
        passenger: document.getElementById('bookPassengerName').value,
        source: document.getElementById('bookSource').value,
        destination: document.getElementById('bookDestination').value,
        date: document.getElementById('bookDate').value,
        class: document.getElementById('bookClass').value,
    };

    try {
        const response = await fetch('http://localhost:8080/api/trains', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(train),
        });
        const data = await response.json();
        displayBookingDetails(data, 'Train booked successfully');
    } catch (error) {
        console.error('Error:', error);
        document.getElementById('bookingDetails').innerHTML = 'Error booking train';
    }
}

async function updateBooking() {
    const train = {
        id: document.getElementById('updateTrainId').value,
        date: document.getElementById('updateDate').value,
        class: document.getElementById('updateClass').value,
    };

    try {
        const response = await fetch(`http://localhost:8080/api/trains/${train.id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(train),
        });
        const data = await response.json();
        displayBookingDetails(data, 'Booking updated successfully');
    } catch (error) {
        console.error('Error:', error);
        document.getElementById('bookingDetails').innerHTML = 'Error updating booking';
    }
}

async function cancelBooking() {
    const trainId = document.getElementById('deleteTrainId').value;

    try {
        await fetch(`http://localhost:8080/api/trains/${trainId}`, {
            method: 'DELETE',
        });
        document.getElementById('bookingDetails').innerHTML = 'Booking canceled successfully';
    } catch (error) {
        console.error('Error:', error);
        document.getElementById('bookingDetails').innerHTML = 'Error canceling booking';
    }
}

async function viewBooking() {
    const trainId = document.getElementById('fetchTrainId').value;

    try {
        const response = await fetch(`http://localhost:8080/api/trains/${trainId}`);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();
        displayBookingDetails(data, 'Booking details fetched successfully');
    } catch (error) {
        console.error('Error:', error);
        document.getElementById('bookingDetails').innerHTML = 'Error fetching booking details';
    }
}

function displayBookingDetails(data, message) {
    if (data.error) {
        document.getElementById('bookingDetails').innerHTML = `<p>${data.error}</p>`;
        return;
    }

    let detailsHTML = `<h2>Booking Details</h2>
                       <p>Train ID: ${data.id}</p>
                       <p>Train Name: ${data.name}</p>
                       <p>Passenger Name: ${data.passenger}</p>
                       <p>Source: ${data.source}</p>
                       <p>Destination: ${data.destination}</p>
                       <p>Date: ${data.date}</p>
                       <p>Class: ${data.class}</p>`;

    if (message) {
        detailsHTML += `<p>${message}</p>`;
    }

    document.getElementById('bookingDetails').innerHTML = detailsHTML;
}
